import { useState } from 'react';

interface Props {
  name: string;
  front: string;
  back: string;
}

export default function FlipCard({ name, front, back }: Props) {
  const [flipped, setFlipped] = useState(false);

  return (
    <button
      onClick={() => setFlipped((f) => !f)}
      className="flip-scene group block w-full text-left focus:outline-none"
      aria-label={`${name} card — tap to turn over`}
    >
      <div className={`flip-inner relative aspect-[9/16] w-full ${flipped ? 'flipped' : ''}`}>
        {/* Front — real card artwork */}
        <div className="flip-face absolute inset-0 overflow-hidden rounded-2xl shadow-xl shadow-rose/20 transition-shadow group-hover:shadow-2xl group-hover:shadow-rose/30">
          <img src={front} alt={`${name} — front of card`} className="h-full w-full object-cover" />
        </div>

        {/* Back — real card artwork */}
        <div className="flip-face flip-back absolute inset-0 overflow-hidden rounded-2xl shadow-xl shadow-rose/20">
          <img src={back} alt={`${name} — back of card`} className="h-full w-full object-cover" />
        </div>
      </div>

      <span className="mt-4 block text-center font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/40 transition group-hover:text-rose-deep">
        {flipped ? 'Turn back over' : 'Turn over →'}
      </span>
    </button>
  );
}
