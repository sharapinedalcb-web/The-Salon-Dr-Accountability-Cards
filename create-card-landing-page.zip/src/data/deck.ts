import { CARD_IMAGES } from './cardImages';

export const PRODUCT = {
  id: '30-days-retail-confidence',
  name: '30 Days to Retail Confidence',
  price: 89,
  tagline: 'The daily card deck for the salon floor.',
  blurb:
    'One card. Five minutes. Every morning, before the first client sits down. The Daily Huddle, in their hands — so retail confidence doesn’t depend on you reminding anyone.',
};

/**
 * ─────────────────────────────────────────────────────────────
 *  PHOTOGRAPH SLOT
 *  Paste a direct image URL here (any https:// link to the photo
 *  of the deck being held). Leave it as '' to show the card fan.
 * ─────────────────────────────────────────────────────────────
 */
export const HERO_PHOTO_URL = '';

export const SAMPLE_CARDS = [
  { id: 'wins', name: 'Three Wins', front: CARD_IMAGES.winsFront, back: CARD_IMAGES.winsBack },
  { id: 'priorities', name: 'Today’s Three Priorities', front: CARD_IMAGES.prioritiesFront, back: CARD_IMAGES.prioritiesBack },
  { id: 'challenge', name: 'Today’s Challenge', front: CARD_IMAGES.challengeFront, back: CARD_IMAGES.challengeBack },
];

/** The three card fronts, in fan order, for the hero composition. */
export const HERO_FAN = [
  CARD_IMAGES.winsFront,
  CARD_IMAGES.prioritiesFront,
  CARD_IMAGES.challengeFront,
];

export const MORNING_STEPS = [
  {
    time: '8:45',
    title: 'Pull today’s card',
    text: 'Whoever opens the salon takes the top card off the deck on the back bar. No prep, no laptop, no slides.',
  },
  {
    time: '8:47',
    title: 'Read the prompt out loud',
    text: 'The front names the ritual. The back is what your team actually says out loud — everyone answers, nobody hides.',
  },
  {
    time: '8:50',
    title: 'Set the day’s commitment',
    text: 'Each stylist names one retail or consultation commitment for the day. Said out loud, it tends to happen.',
  },
  {
    time: '8:50+',
    title: 'Open the doors',
    text: 'Five minutes, done. The team walks to their chairs focused, aligned and ready to recommend with confidence.',
  },
];

export const INCLUDES = [
  { icon: '🃏', title: '30 daily huddle cards', text: 'A month of five-minute morning rituals — wins, priorities, challenges, scripts and commitments.' },
  { icon: '📦', title: 'Back-bar display box', text: 'A sturdy keepsake box that lives on the back bar, so the ritual is impossible to forget.' },
  { icon: '📝', title: 'Owner’s guide card', text: 'How to run the huddle, rotate who leads it, and keep it alive after the first 30 days.' },
  { icon: '🔁', title: 'Restart-proof design', text: 'Finished the 30 days? Shuffle and go again. The prompts are built to be repeated.' },
];

export const formatAUD = (n: number) =>
  n.toLocaleString('en-AU', { style: 'currency', currency: 'AUD', minimumFractionDigits: 0 });
