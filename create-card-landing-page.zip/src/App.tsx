import { useEffect, useState } from 'react';
import { PRODUCT, SAMPLE_CARDS, HERO_FAN, HERO_PHOTO_URL, MORNING_STEPS, INCLUDES, formatAUD } from './data/deck';
import FlipCard from './components/FlipCard';
import BagDrawer from './components/BagDrawer';
import Logo from './components/Logo';





function Heartbeat({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 220 28" className={`mx-auto h-7 w-auto text-rose ${className}`} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 14h55l8-10 10 20 8-10h28l7-7 9 14 7-7h78" />
    </svg>
  );
}

export default function App() {
  const [qty, setQty] = useState(0);
  const [bagOpen, setBagOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [toast, setToast] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const addToBag = () => {
    setQty((q) => Math.min(10, q + 1));
    setToast(true);
    setTimeout(() => setToast(false), 2200);
  };

  return (
    <div id="top" className="min-h-screen bg-cream font-body text-ink">
      {/* ─── Header ─── */}
      <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-cream/90 py-2.5 shadow-[0_1px_0_rgba(33,33,33,0.08)] backdrop-blur-xl' : 'py-4'}`}>
        <div className="mx-auto flex w-full max-w-7xl items-center gap-3 px-4">
          <a href="#top" className="flex shrink-0 items-center">
            <Logo tone="dark" />
          </a>
          <nav className="ml-auto hidden items-center gap-x-5 md:flex">
            {[['The Deck', '#deck'], ['The Cards', '#cards'], ['The Morning', '#morning'], ['What’s Inside', '#inside']].map(([label, href]) => (
              <a key={href} href={href} className="whitespace-nowrap text-[13px] font-medium text-ink/70 transition hover:text-rose-deep">
                {label}
              </a>
            ))}
          </nav>
          <div className="ml-auto flex shrink-0 items-center gap-2 md:ml-3">
            <button
              onClick={() => setBagOpen(true)}
              aria-label={`Bag, ${qty} items`}
              className="relative grid h-11 w-11 place-items-center rounded-full border border-ink/15 bg-white/80 transition hover:border-rose"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden>
                <path d="M6.5 8h11l-.8 12.2a1 1 0 0 1-1 .8H8.3a1 1 0 0 1-1-.8L6.5 8z" />
                <path d="M9 8V6.8A3 3 0 0 1 12 3.8 3 3 0 0 1 15 6.8V8" />
              </svg>
              {qty > 0 && (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-rose px-1 text-[10px] font-semibold text-white">{qty}</span>
              )}
            </button>
            <button onClick={addToBag} className="hidden rounded-full bg-rose-deep px-5 py-2.5 font-display text-xs font-semibold uppercase tracking-[0.15em] text-cream transition hover:bg-ink sm:inline-flex">
              Add to bag · {formatAUD(PRODUCT.price)}
            </button>
          </div>
        </div>
      </header>

      {/* Added-to-bag toast */}
      {toast && (
        <div className="fixed left-1/2 top-20 z-[70] -translate-x-1/2 rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-cream shadow-xl">
          ✓ Added to bag
        </div>
      )}

      {/* ─── Hero ─── */}
      <section id="deck" className="relative overflow-hidden pb-20 pt-32 md:pt-40">
        <div className="pointer-events-none absolute -left-32 top-80 h-96 w-96 rounded-full bg-sand/60 blur-3xl" />
        <div className="pointer-events-none absolute -right-32 -top-40 h-[28rem] w-[28rem] rounded-full bg-blush/40 blur-3xl" />

        <div className="relative mx-auto grid w-full max-w-7xl items-center gap-12 px-4 lg:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-rose/40 bg-white/70 px-4 py-1.5 font-display text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-deep backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-rose" /> Now in the shop · Card deck · Physical
            </span>
            <h1 className="mt-6 font-display text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              The 30 days,
              <br />
              <span className="text-rose-deep">in their hands.</span>
            </h1>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink/70">{PRODUCT.blurb}</p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button onClick={addToBag} className="rounded-full bg-rose-deep px-8 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream shadow-lg shadow-rose/30 transition hover:bg-ink">
                Add to bag — {formatAUD(PRODUCT.price)}
              </button>
              <a href="#cards" className="rounded-full border border-ink/20 bg-white/70 px-7 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-ink backdrop-blur transition hover:border-rose">
                Turn the cards →
              </a>
            </div>
            <p className="mt-5 text-xs text-ink/50">
              Complimentary shipping across Australia · One deck runs the whole team’s huddle
            </p>
          </div>

          <div className="relative pb-10">
            {HERO_PHOTO_URL ? (
              /* Photograph of the deck in hand */
              <div className="relative mx-auto aspect-[4/5] w-full max-w-md overflow-hidden rounded-[2rem] border border-sand shadow-2xl shadow-rose/25">
                <img
                  src={HERO_PHOTO_URL}
                  alt="Sonia Tomas fanning the 30 Days to Retail Confidence huddle cards"
                  className="h-full w-full object-cover"
                />
              </div>
            ) : (
              /* Fanned deck built from the real card artwork */
              <div className="relative mx-auto aspect-[4/5] w-full max-w-md">
                <div className="pointer-events-none absolute inset-8 rounded-full bg-blush/40 blur-3xl" />
                {HERO_FAN.map((src, i) => {
                  const offset = i - 1;
                  return (
                    <div
                      key={i}
                      className="absolute left-1/2 top-1/2 w-[46%] overflow-hidden rounded-xl border border-white/60 shadow-2xl shadow-rose-deep/25 transition-transform duration-500 ease-out hover:z-10 hover:-translate-y-3"
                      style={{
                        transform: `translate(-50%, -50%) translateX(${offset * 26}%) rotate(${offset * 11}deg)`,
                        zIndex: i === 1 ? 3 : i,
                      }}
                    >
                      <img
                        src={src}
                        alt={`30 Days to Retail Confidence card — ${SAMPLE_CARDS[i].name}`}
                        className="aspect-[9/16] w-full object-cover"
                      />
                    </div>
                  );
                })}
              </div>
            )}
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-2xl border border-sand bg-white px-5 py-3 text-center shadow-xl">
              <p className="font-display text-xs font-semibold uppercase tracking-[0.15em] text-rose-deep">{PRODUCT.name}</p>
              <p className="mt-0.5 text-xs text-ink/50">{PRODUCT.tagline}</p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Trust strip ─── */}
      <section className="border-y border-sand bg-white/60">
        <div className="mx-auto grid max-w-5xl gap-4 px-4 py-6 text-center sm:grid-cols-3">
          {['✓ Free shipping in Australia', '✓ Arrives in 5–8 days', '✓ One deck, whole team'].map((t) => (
            <p key={t} className="font-display text-xs font-semibold uppercase tracking-[0.15em] text-ink/70">{t}</p>
          ))}
        </div>
      </section>

      {/* ─── Problem / promise ─── */}
      <section className="mx-auto max-w-3xl px-4 py-20 text-center">
        <Heartbeat />
        <h2 className="mt-6 font-display text-3xl font-semibold leading-snug sm:text-4xl">
          Most retail training evaporates by Wednesday. <span className="text-rose-deep">This deck doesn’t let it.</span>
        </h2>
        <p className="mt-6 text-lg leading-relaxed text-ink/60">
          Training day starts the habit. This deck is what keeps it alive at 8:45 every morning — with or without Sonia in the room.
        </p>
      </section>

      {/* ─── Flip cards ─── */}
      <section id="cards" className="bg-gradient-to-b from-cream to-sand/40 py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.25em] text-rose-deep">Sample the ritual</span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">Three cards from the deck. Turn them over.</h2>
            <p className="mt-4 leading-relaxed text-ink/60">
              This is a taste, not the whole 30 days. The front names the ritual. The back is what your team actually says out loud. Tap any card.
            </p>
          </div>
          <div className="mx-auto mt-12 grid max-w-4xl gap-8 sm:grid-cols-3">
            {SAMPLE_CARDS.map((c) => (
              <FlipCard key={c.id} name={c.name} front={c.front} back={c.back} />
            ))}
          </div>
        </div>
      </section>

      {/* ─── How the morning runs ─── */}
      <section id="morning" className="py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 lg:grid-cols-2">
          <div className="order-2 lg:order-1">
            <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-sand via-blush to-rose p-8 shadow-2xl shadow-rose/20 sm:p-12">
              <div className="relative mx-auto max-w-xs rotate-[-4deg] overflow-hidden rounded-2xl border border-white/60 shadow-2xl shadow-rose-deep/30">
                <img
                  src={SAMPLE_CARDS[2].back}
                  alt="Back of a 30 Days to Retail Confidence huddle card"
                  className="aspect-[9/16] w-full object-cover"
                />
              </div>
              <div className="relative mt-8 text-center">
                <p className="font-display text-[10px] font-semibold uppercase tracking-[0.22em] text-rose-deep">
                  In the room
                </p>
                <p className="mt-2 font-display text-lg font-semibold leading-snug text-ink">
                  Sonia Tomas, founder of The Salon Dr.
                </p>
              </div>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.25em] text-rose-deep">The Daily Huddle</span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">How the morning runs.</h2>
            <p className="mt-4 leading-relaxed text-ink/60">Five minutes. No slides. The deck does the facilitating.</p>
            <ol className="mt-8 space-y-6">
              {MORNING_STEPS.map((s) => (
                <li key={s.time} className="flex gap-5">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-sand font-display text-xs font-semibold text-rose-deep">{s.time}</span>
                  <div>
                    <h3 className="font-display font-semibold">{s.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-ink/60">{s.text}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* ─── What's inside ─── */}
      <section id="inside" className="bg-white/60 py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.25em] text-rose-deep">In the box</span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">What’s inside the deck.</h2>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {INCLUDES.map((f) => (
              <div key={f.title} className="rounded-3xl border border-sand bg-cream p-7 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-rose/15">
                <span className="text-3xl">{f.icon}</span>
                <h3 className="mt-4 font-display font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink/60">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Buy section ─── */}
      <section className="pb-24">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <Heartbeat />
          <h2 className="mt-6 font-display text-3xl font-semibold sm:text-4xl">
            8:45 tomorrow morning could sound different.
          </h2>
          <p className="mx-auto mt-5 max-w-xl leading-relaxed text-ink/60">
            One deck. {formatAUD(PRODUCT.price)}. Free shipping anywhere in Australia. Put it on the back bar the morning it lands, and let the cards run the huddle.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <button onClick={addToBag} className="rounded-full bg-rose-deep px-9 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream shadow-lg shadow-rose/30 transition hover:bg-ink">
              Add to bag — {formatAUD(PRODUCT.price)}
            </button>
            <button onClick={() => setBagOpen(true)} className="rounded-full border border-ink/20 px-8 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-ink transition hover:border-rose">
              View bag {qty > 0 ? `(${qty})` : ''}
            </button>
          </div>
          <p className="mt-5 text-xs text-ink/40">
            You’ll be contacted to confirm payment and delivery. No card is charged on this page.
          </p>
        </div>
      </section>

      {/* ─── Footer ─── */}
      <footer className="border-t border-sand bg-white/60">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-6 px-4 py-10 text-center md:flex-row md:justify-between md:text-left">
          <a href="#top" className="flex shrink-0 items-center">
            <Logo tone="dark" showTagline />
          </a>
          <p className="max-w-md text-xs leading-relaxed text-ink/50">
            {PRODUCT.name} — {PRODUCT.tagline} In-salon sales &amp; retail training, Australia-wide.
          </p>
        </div>
        <div className="border-t border-sand/70 py-4 text-center text-[11px] text-ink/40">
          © {new Date().getFullYear()} The Salon Dr. · All rights reserved
        </div>
      </footer>

      <BagDrawer open={bagOpen} qty={qty} onClose={() => setBagOpen(false)} onSetQty={setQty} />
    </div>
  );
}
